"use strict";window.addEventListener("message",function(a){a.source==window&&a.data&&a.data.ext&&"scrapekit"==a.data.ext&&"background"==a.data.to&&chrome.runtime.sendMessage({action:a.data.action,data:a.data.data},function(t){postMessage({ext:"scrapekit",to:"page",action:a.data.action,data:t},"*")})},!1);
//# sourceMappingURL=contentscript.js.map
